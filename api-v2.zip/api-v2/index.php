<?php
require_once 'config/database.php';
require_once 'config/cors.php';

echo json_encode(["message" => "API funcionando"]);
?>